package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // Değişkenleri sadece bir kez ve doğru yazımla tanımlıyoruz
    TextView sonucEkrani;
    double ilkSayi = 0;
    String secilenIslem = "";
    boolean yeniSayiBasliyorMu = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Tasarımdaki ID ile buradaki ID'nin aynı olduğundan emin ol
        sonucEkrani = findViewById(R.id.textViewSonuc);
    }

    // Tüm rakam butonlarına (0-9) Attributes panelinden bu fonksiyonu ata
    public void rakamTikla(View view) {
        if (yeniSayiBasliyorMu) {
            sonucEkrani.setText("");
            yeniSayiBasliyorMu = false;
        }
        Button buton = (Button) view;
        String mevcutYazi = sonucEkrani.getText().toString();
        sonucEkrani.setText(mevcutYazi + buton.getText().toString());
    }

    // İşlem butonlarına (+, -, *, /) bu fonksiyonu ata
    public void islemTikla(View view) {
        Button buton = (Button) view;
        secilenIslem = buton.getText().toString();

        // Eğer ekran boşsa hata almamak için kontrol ekliyoruz
        if (!sonucEkrani.getText().toString().equals("")) {
            ilkSayi = Double.parseDouble(sonucEkrani.getText().toString());
            yeniSayiBasliyorMu = true;
        }
    }

    // Eşittir (=) butonuna bu fonksiyonu ata
    public void esittirTikla(View view) {
        if (sonucEkrani.getText().toString().equals("")) return;

        double ikinciSayi = Double.parseDouble(sonucEkrani.getText().toString());
        double netice = 0;

        switch (secilenIslem) {
            case "+": netice = ilkSayi + ikinciSayi; break;
            case "-": netice = ilkSayi - ikinciSayi; break;
            case "*": netice = ilkSayi * ikinciSayi; break;
            case "/":
                if (ikinciSayi != 0) netice = ilkSayi / ikinciSayi;
                else {
                    sonucEkrani.setText("Hata!");
                    yeniSayiBasliyorMu = true;
                    return;
                }
                break;
        }

        sonucEkrani.setText(String.valueOf(netice));
        yeniSayiBasliyorMu = true;
    }

    // Temizle (C) butonuna bu fonksiyonu ata
    public void temizleTikla(View view) {
        sonucEkrani.setText("0");
        ilkSayi = 0;
        secilenIslem = "";
        yeniSayiBasliyorMu = true;
    }
}